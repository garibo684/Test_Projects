#pragma once

namespace converter {
  float ConvertFromTL(float, const std::string&);
  float ConvertToTL(float, const std::string&);
}